# MERN Todo Application

Hello 👋, I'm Azim Uddin Ahamed. At this repository i built a `Complete MERN Stack TODO Application ☋`. Using `Node.js, Express.js, MongoDB, React.js, Redux.js & Tailwind CSS`.

<!-- ahead of main parts -->
### Want to collaborate? mail me ` azimaahmed36@gmail.com`

### 👨‍💻 Development with MERN Stack Todo Application


- `Backend` - Node.js, Express.js & MongoDB database
- `Frontend` - React.js, Redux.js, & Tailwind CSS
